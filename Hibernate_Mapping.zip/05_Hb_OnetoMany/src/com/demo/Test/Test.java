package com.demo.Test;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.demo.Bean.OtoM_person;
import com.demo.Bean.Veichle;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		Session session = factory.openSession();

		session.beginTransaction();

		List<Veichle> vl = new ArrayList<Veichle>();
		vl.add(new Veichle(101, "RR"));
		vl.add(new Veichle(102, "BMW"));

		OtoM_person m_person = new OtoM_person(501, "Abhi", vl);

		session.save(vl.get(0));
		session.save(vl.get(1));
		session.save(m_person);
		session.getTransaction().commit();

		session.close();
	}

}
