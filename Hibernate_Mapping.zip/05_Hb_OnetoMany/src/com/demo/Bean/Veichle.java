package com.demo.Bean;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Veichle {
	@Id
	int v_id;
	String name;
	public Veichle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Veichle(int v_id, String name) {
		super();
		this.v_id = v_id;
		this.name = name;
	}
	public int getV_id() {
		return v_id;
	}
	public void setV_id(int v_id) {
		this.v_id = v_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Veichle [v_id=" + v_id + ", name=" + name + "]";
	}
	
	
	
	
	
}
