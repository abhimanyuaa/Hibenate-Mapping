package com.demo.Bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class OtoM_person {

	@Id
	int id;
	String name;
	@OneToMany
	List<Veichle> veichle;
	public OtoM_person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public OtoM_person(int id, String name, List<Veichle> veichle) {
		super();
		this.id = id;
		this.name = name;
		this.veichle = veichle;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Veichle> getVeichle() {
		return veichle;
	}
	public void setVeichle(List<Veichle> veichle) {
		this.veichle = veichle;
	}
	@Override
	public String toString() {
		return "OtoM_person [id=" + id + ", name=" + name + ", veichle=" + veichle + "]";
	}

	
	
	
}
