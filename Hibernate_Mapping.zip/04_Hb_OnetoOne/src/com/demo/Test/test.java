package com.demo.Test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.demo.bean.Employee;
import com.demo.bean.Laptop;

public class test {

	
	public static void main(String[] args) {
		
		SessionFactory factory= new Configuration().configure().buildSessionFactory();
		

	
		Session session=factory.openSession();
		
		session.beginTransaction();
		
		Laptop laptop= new Laptop(101, "Dell");
		
		Employee employee= new Employee(201, "Ravi", laptop);
		
		session.save(laptop);
		
		session.save(employee);
		
		session.getTransaction().commit();
		
		session.close();
		
	}
}
